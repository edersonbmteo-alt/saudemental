import React, { useState } from "react";
import { Play, ExternalLink, ArrowRight, Sparkles, HeartHandshake, Eye, CheckCircle2 } from "lucide-react";

interface Challenge1Props {
  onContinue: () => void;
}

export const Challenge1Intro: React.FC<Challenge1Props> = ({ onContinue }) => {
  const [videoOpened, setVideoOpened] = useState(false);

  const handleOpenVideo = () => {
    setVideoOpened(true);
    window.open("https://www.youtube.com/watch?v=I5dkgyfs5pU", "_blank", "noopener,noreferrer");
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6">
      <div className="rounded-3xl bg-slate-900/90 border border-amber-500/30 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
        {/* Title Header */}
        <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-800">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 text-2xl">
            🎬
          </div>
          <div>
            <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
              Desafio 1 de 8
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-['Outfit']">
              Ponto de Partida: Curta “Lou” (Pixar)
            </h2>
          </div>
        </div>

        {/* Video Thumbnail Button */}
        <div className="mb-8">
          <p className="text-sm text-slate-300 mb-3 font-medium flex items-center gap-2">
            <Eye className="w-4 h-4 text-amber-400" />
            Clique na imagem abaixo para assistir ao curta no YouTube:
          </p>

          <div
            onClick={handleOpenVideo}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") handleOpenVideo();
            }}
            id="btn-assistir-lou"
            className="group relative cursor-pointer overflow-hidden rounded-2xl border-2 border-amber-500/40 hover:border-amber-400 bg-slate-950 shadow-xl transition-all duration-300 hover:shadow-amber-500/20 max-w-2xl mx-auto"
          >
            {/* Thumbnail Image */}
            <div className="relative aspect-video w-full overflow-hidden bg-slate-950">
              <img
                src="https://img.youtube.com/vi/I5dkgyfs5pU/hqdefault.jpg"
                alt="Miniatura do curta Lou da Pixar"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/30 to-transparent group-hover:via-slate-950/10 transition-colors" />

              {/* Play Button Badge */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-amber-500/90 text-slate-950 flex items-center justify-center shadow-2xl ring-4 ring-amber-400/40 group-hover:scale-110 group-hover:bg-amber-400 transition-all duration-300">
                  <Play className="w-8 h-8 fill-current ml-1" />
                </div>
              </div>

              {/* Tag bottom */}
              <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-amber-200 bg-slate-950/80 px-3 py-1.5 rounded-lg backdrop-blur-sm border border-amber-500/20">
                <span className="font-semibold">Curta “Lou” (Pixar Animation Studios)</span>
                <span className="flex items-center gap-1 text-slate-300">
                  Abrir no YouTube <ExternalLink className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          </div>

          {videoOpened && (
            <div className="mt-3 flex items-center justify-center gap-2 text-xs font-medium text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
              Vídeo aberto no YouTube! Quando terminar de assistir, leia a reflexão abaixo e continue.
            </div>
          )}
        </div>

        {/* Reflective Introduction */}
        <div className="space-y-4 text-slate-300 text-sm sm:text-base leading-relaxed bg-slate-950/50 p-6 rounded-2xl border border-slate-800">
          <div className="flex items-center gap-2 text-amber-300 font-bold text-base">
            <HeartHandshake className="w-5 h-5 text-amber-400" />
            Para Pensar e Sentir:
          </div>

          <p>
            No curta <strong>Lou</strong>, observamos o comportamento do personagem J.J. no recreio escolar. Muitas vezes, atitudes que parecem “apenas brincadeiras” escondem sentimentos de carência, mágoa ou isolamento — e acabam gerando exclusão e sofrimento em outros colegas.
          </p>

          <p>
            O personagem <em>Lou</em>, feito de objetos esquecidos da caixa de achados e perdidos, nos ensina uma lição valiosa: em vez de apenas punir, ele convida J.J. a <strong>reparar o mal causado</strong> e a descobrir a alegria genuína de devolver o que tirou, de acolher e de ser aceito pelo grupo.
          </p>

          <div className="pt-2 grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-semibold text-center">
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300">
              🤝 Convivência & Respeito
            </div>
            <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-300">
              💛 Empatia nas Ações
            </div>
            <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300">
              🌱 Reparação & Mudança
            </div>
            <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-300">
              ✨ Cuidado com o Outro
            </div>
          </div>
        </div>

        {/* Navigation Action */}
        <div className="mt-8 flex justify-end pt-4 border-t border-slate-800">
          <button
            type="button"
            id="btn-continuar-desafio-1"
            onClick={onContinue}
            className="group inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
          >
            <span>CONTINUAR →</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </button>
        </div>
      </div>
    </div>
  );
};
