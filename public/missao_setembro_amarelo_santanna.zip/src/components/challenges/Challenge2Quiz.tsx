import React, { useState } from "react";
import { ArrowLeft, ArrowRight, HelpCircle, CheckCircle2, AlertCircle, Sparkles } from "lucide-react";
import { QuizQuestion } from "../../types";

const QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "No curta, algumas atitudes podem parecer brincadeiras. O que ajuda a perceber com clareza que uma atitude ultrapassou o limite da brincadeira saudável?",
    context: "Reflexão sobre limites e convivência no espaço escolar",
    options: [
      {
        id: "1a",
        text: "Quando quem fez a brincadeira achou muito engraçado e todos ao redor riram alto.",
        isCorrect: false,
        reflection: "O riso de terceiros não valida uma ação se alguém foi magoado ou ridicularizado."
      },
      {
        id: "1b",
        text: "Quando a atitude gera humilhação, exclusão, vergonha ou sofrimento para quem a recebe.",
        isCorrect: true,
        reflection: "Exatamente. O limite ético de qualquer brincadeira é o respeito e a integridade emocional do outro."
      },
      {
        id: "1c",
        text: "Apenas se um professor ou inspetor intervier imediatamente na hora do recreio.",
        isCorrect: false,
        reflection: "A consciência sobre o respeito deve nascer das nossas próprias escolhas, não apenas da vigilância externa."
      },
      {
        id: "1d",
        text: "Contanto que não haja agressão física visível, qualquer provocação verbal é aceitável.",
        isCorrect: false,
        reflection: "Palavras e exclusão causam dores emocionais profundas que também ferem."
      }
    ]
  },
  {
    id: 2,
    question: "Em uma situação de convivência em grupo, qual atitude demonstra a essência da empatia?",
    context: "Compreensão e conexão com as emoções alheias",
    options: [
      {
        id: "2a",
        text: "Tentar impor a sua própria opinião com calma até que os colegas concordem com você.",
        isCorrect: false,
        reflection: "Empatia não é convencer os outros, mas abrir espaço para compreender o que eles sentem."
      },
      {
        id: "2b",
        text: "Considerar os sentimentos e a realidade do outro antes de falar ou tomar qualquer atitude.",
        isCorrect: true,
        reflection: "Perfeito! Colocar-se no lugar do colega com sinceridade orienta atitudes muito mais acolhedoras."
      },
      {
        id: "2c",
        text: "Ignorar o que o colega está sentindo para não criar clima pesado na turma.",
        isCorrect: false,
        reflection: "Fingir que nada aconteceu ou ignorar o sofrimento alheio reforça o sentimento de solidão."
      },
      {
        id: "2d",
        text: "Esperar que o outro resolva seus sentimentos sozinho, já que cada um cuida de si.",
        isCorrect: false,
        reflection: "A vida em comunidade e a amizade se fortalecem no apoio mútuo."
      }
    ]
  },
  {
    id: 3,
    question: "Se você perceber que uma atitude ou comentário seu acabou machucando um colega, qual seria uma postura verdadeiramente responsável?",
    context: "Reparação e maturidade nas relações",
    options: [
      {
        id: "3a",
        text: "Dizer 'você é sensível demais, não aguenta nada' e esperar que ele esqueça.",
        isCorrect: false,
        reflection: "Desqualificar a dor do outro é uma forma de justificar o próprio erro e amplia a mágoa."
      },
      {
        id: "3b",
        text: "Reconhecer o impacto gerado, escutar o que o colega sentiu e procurar sinceramente reparar o erro.",
        isCorrect: true,
        reflection: "Excelente. Ter a coragem de assumir o impacto das ações e reparar é a marca da verdadeira maturidade."
      },
      {
        id: "3c",
        text: "Ficar em silêncio e evitar conversar com esse colega pelas próximas semanas.",
        isCorrect: false,
        reflection: "O afastamento sem diálogo não resolve o mal-entendido e pode deixar uma ferida aberta."
      },
      {
        id: "3d",
        text: "Culpar os outros colegas que estavam por perto por terem incentivado a atitude.",
        isCorrect: false,
        reflection: "Transferir a culpa não demonstra responsabilidade pessoal pelas próprias ações."
      }
    ]
  },
  {
    id: 4,
    question: "Ao perceber que um colega de sala está sendo constantemente isolado ou ficando sozinho nos intervalos, qual atitude demonstra cuidado genuíno?",
    context: "Acolhimento e inclusão no cotidiano",
    options: [
      {
        id: "4a",
        text: "Aproximar-se para acolher, convidar para uma conversa ou atividade e, se perceber sofrimento contínuo, procurar a orientação de um adulto de confiança.",
        isCorrect: true,
        reflection: "Muito bem! Pequenos gestos de aproximação quebram o isolamento e criam pontes de segurança."
      },
      {
        id: "4b",
        text: "Presumir que ele prefere ficar sozinho e não tentar nenhum tipo de aproximação.",
        isCorrect: false,
        reflection: "Muitas vezes quem está isolado deseja companhia e acolhimento, mas não tem forças ou segurança para pedir."
      },
      {
        id: "4c",
        text: "Fazer piadas em voz alta sobre o isolamento dele para ver se ele reage e interage.",
        isCorrect: false,
        reflection: "Isso aumenta ainda mais a timidez, o constrangimento e o sofrimento da pessoa."
      },
      {
        id: "4d",
        text: "Comentar com outros colegas como ele é estranho por não conversar com ninguém.",
        isCorrect: false,
        reflection: "Julgamentos e fofocas afastam ainda mais e alimentam o ciclo da exclusão."
      }
    ]
  },
  {
    id: 5,
    question: "Por que pedir ajuda quando estamos passando por um momento difícil é considerado um ato de profunda coragem e cuidado com a vida?",
    context: "Valorização da vida e rede de apoio",
    options: [
      {
        id: "5a",
        text: "Porque pedir ajuda é um sinal de que não somos fortes o bastante para vencer sozinhos.",
        isCorrect: false,
        reflection: "Pelo contrário: ninguém precisa nem deve carregar tudo sozinho. Buscar apoio é força, não fraqueza."
      },
      {
        id: "5b",
        text: "Porque reconhecer a própria dor e compartilhar momentos difíceis com alguém de confiança torna os fardos mais leves e os caminhos mais seguros.",
        isCorrect: true,
        reflection: "Com certeza! Falar sobre o que sentimos abre caminhos de acolhimento, esperança e superação."
      },
      {
        id: "5c",
        text: "Apenas para que os outros façam as coisas difíceis em nosso lugar.",
        isCorrect: false,
        reflection: "Pedir ajuda nos dá apoio e clareza para enfrentarmos os desafios com mais esperança."
      },
      {
        id: "5d",
        text: "Porque guardar tudo para si sempre resolve os problemas sem preocupar ninguém.",
        isCorrect: false,
        reflection: "Guardar o sofrimento em silêncio sobrecarrega o coração. Compartilhar alivia e salva vidas."
      }
    ]
  }
];

interface Challenge2Props {
  onBack: () => void;
  onContinue: (scoreString: string, details: string) => void;
  initialAnswers?: Record<number, string>;
}

export const Challenge2Quiz: React.FC<Challenge2Props> = ({
  onBack,
  onContinue,
  initialAnswers = {},
}) => {
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>(initialAnswers);
  const [showFeedback, setShowFeedback] = useState<Record<number, boolean>>({});

  const handleSelect = (questionId: number, optionId: string) => {
    setSelectedAnswers((prev) => ({ ...prev, [questionId]: optionId }));
    setShowFeedback((prev) => ({ ...prev, [questionId]: true }));
  };

  const answeredCount = Object.keys(selectedAnswers).length;
  const isComplete = answeredCount === QUESTIONS.length;

  const calculateScore = () => {
    let correct = 0;
    QUESTIONS.forEach((q) => {
      const selectedId = selectedAnswers[q.id];
      const opt = q.options.find((o) => o.id === selectedId);
      if (opt?.isCorrect) correct++;
    });
    return {
      correct,
      total: QUESTIONS.length,
      scoreString: `${correct}/${QUESTIONS.length} acertos (${Math.round((correct / QUESTIONS.length) * 100)}%)`,
    };
  };

  const handleFinish = () => {
    const { scoreString } = calculateScore();
    const details = QUESTIONS.map((q) => {
      const selectedId = selectedAnswers[q.id];
      const opt = q.options.find((o) => o.id === selectedId);
      return `Q${q.id}: ${opt?.isCorrect ? "Correto" : "Incorreto"} (Opção: ${opt?.text.slice(0, 40)}...)`;
    }).join(" | ");

    onContinue(scoreString, details);
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6">
      <div className="rounded-3xl bg-slate-900/90 border border-amber-500/30 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
        {/* Title Header */}
        <div className="flex items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 text-2xl">
              🧠
            </div>
            <div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                Desafio 2 de 8
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-['Outfit']">
                Desafio do Conhecimento
              </h2>
            </div>
          </div>
          <div className="text-right">
            <span className="text-xs font-semibold text-slate-400">Respondidas:</span>
            <div className="text-sm font-bold text-amber-400">
              {answeredCount} de {QUESTIONS.length}
            </div>
          </div>
        </div>

        <p className="text-sm text-slate-300 mb-6">
          Leia atentamente cada situação. As questões são reflexivas e foram pensadas para provocar uma reflexão honesta sobre o nosso dia a dia.
        </p>

        {/* Questions List */}
        <div className="space-y-6">
          {QUESTIONS.map((q, idx) => {
            const selectedOptId = selectedAnswers[q.id];
            const isAnswered = Boolean(selectedOptId);
            const selectedOpt = q.options.find((o) => o.id === selectedOptId);

            return (
              <div
                key={q.id}
                className="rounded-2xl bg-slate-950/60 border border-slate-800 p-5 sm:p-6 transition-all"
              >
                <div className="flex items-start gap-3 mb-3">
                  <span className="w-7 h-7 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <div>
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-amber-400/80">
                      {q.context}
                    </span>
                    <h3 className="text-base sm:text-lg font-bold text-white mt-0.5">
                      {q.question}
                    </h3>
                  </div>
                </div>

                {/* Options */}
                <div className="space-y-2.5 mt-4">
                  {q.options.map((opt) => {
                    const isSelected = selectedOptId === opt.id;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => handleSelect(q.id, opt.id)}
                        className={`w-full text-left p-3.5 rounded-xl border text-sm transition-all duration-200 flex items-start gap-3 cursor-pointer ${
                          isSelected
                            ? opt.isCorrect
                              ? "bg-emerald-500/15 border-emerald-500/60 text-emerald-100 shadow-md shadow-emerald-950/30"
                              : "bg-amber-500/15 border-amber-500/50 text-amber-100"
                            : "bg-slate-900/70 border-slate-800 hover:border-amber-500/40 text-slate-300 hover:text-white"
                        }`}
                      >
                        <div
                          className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold ${
                            isSelected
                              ? opt.isCorrect
                                ? "border-emerald-400 bg-emerald-500 text-slate-950"
                                : "border-amber-400 bg-amber-500 text-slate-950"
                              : "border-slate-600 bg-slate-800 text-slate-400"
                          }`}
                        >
                          {isSelected ? (
                            opt.isCorrect ? (
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            ) : (
                              "•"
                            )
                          ) : (
                            opt.id.slice(-1).toUpperCase()
                          )}
                        </div>
                        <span className="leading-relaxed">{opt.text}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Instant Reflective Feedback */}
                {isAnswered && selectedOpt && (
                  <div
                    className={`mt-4 p-3.5 rounded-xl border text-xs leading-relaxed flex items-start gap-2.5 ${
                      selectedOpt.isCorrect
                        ? "bg-emerald-950/40 border-emerald-500/30 text-emerald-200"
                        : "bg-amber-950/40 border-amber-500/30 text-amber-200"
                    }`}
                  >
                    {selectedOpt.isCorrect ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <strong className="block font-bold">
                        {selectedOpt.isCorrect ? "Reflexão Positiva:" : "Ponto de Atenção:"}
                      </strong>
                      {selectedOpt.reflection}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Navigation Actions */}
        <div className="mt-8 flex items-center justify-between pt-4 border-t border-slate-800">
          <button
            type="button"
            id="btn-voltar-desafio-2"
            onClick={onBack}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-sm transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>← VOLTAR</span>
          </button>

          <button
            type="button"
            id="btn-continuar-desafio-2"
            disabled={!isComplete}
            onClick={handleFinish}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-amber-500/20 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
          >
            <span>CONTINUAR →</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
