import React, { useState } from "react";
import { ArrowLeft, ArrowRight, Sparkles, Star, Check, Compass } from "lucide-react";

interface Challenge7Props {
  onBack: () => void;
  onContinue: (
    selectedQualities: string[],
    qualityRecognized: string,
    qualityToDevelop: string
  ) => void;
  initialSelected?: string[];
  initialRecognized?: string;
  initialToDevelop?: string;
}

const QUALITIES_LIST = [
  "Atencioso(a)",
  "Criativo(a)",
  "Responsável",
  "Amigo(a)",
  "Corajoso(a)",
  "Paciente",
  "Gentil",
  "Esforçado(a)",
  "Solidário(a)",
  "Curioso(a)",
  "Respeitoso(a)",
  "Persistente",
  "Leal",
  "Determinado(a)",
  "Colaborativo(a)",
];

export const Challenge7Qualities: React.FC<Challenge7Props> = ({
  onBack,
  onContinue,
  initialSelected = [],
  initialRecognized = "",
  initialToDevelop = "",
}) => {
  const [selectedQualities, setSelectedQualities] = useState<string[]>(initialSelected);
  const [qualityRecognized, setQualityRecognized] = useState(initialRecognized);
  const [qualityToDevelop, setQualityToDevelop] = useState(initialToDevelop);
  const [error, setError] = useState<string | null>(null);

  const toggleQuality = (item: string) => {
    setSelectedQualities((prev) =>
      prev.includes(item) ? prev.filter((q) => q !== item) : [...prev, item]
    );
  };

  const handleFinish = () => {
    if (selectedQualities.length === 0) {
      setError("Por favor, selecione ao menos uma qualidade com a qual você se identifica.");
      return;
    }
    if (!qualityRecognized.trim()) {
      setError("Por favor, preencha a qualidade que você reconhece em você.");
      return;
    }
    if (!qualityToDevelop.trim()) {
      setError("Por favor, preencha a qualidade que você gostaria de desenvolver ainda mais.");
      return;
    }

    setError(null);
    onContinue(selectedQualities, qualityRecognized.trim(), qualityToDevelop.trim());
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6">
      <div className="rounded-3xl bg-slate-900/90 border border-amber-500/30 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
        {/* Title Header */}
        <div className="flex items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 text-2xl">
              🌟
            </div>
            <div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                Desafio 7 de 8
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-['Outfit']">
                Reconheça Suas Qualidades
              </h2>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs font-semibold text-slate-400">Selecionadas:</span>
            <div className="text-sm font-bold text-amber-400">
              {selectedQualities.length}
            </div>
          </div>
        </div>

        <p className="text-sm text-slate-300 mb-6 leading-relaxed">
          Reconhecer nosso próprio valor é parte fundamental da nossa saúde emocional e da valorização da vida. Você possui forças e virtudes únicas!
        </p>

        {/* Qualities Grid Selection */}
        <div className="mb-8">
          <label className="block text-xs font-bold text-amber-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <Star className="w-3.5 h-3.5" />
            1. Clique nas qualidades que você reconhece em si mesmo(a):
          </label>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
            {QUALITIES_LIST.map((quality) => {
              const isSelected = selectedQualities.includes(quality);
              return (
                <button
                  key={quality}
                  type="button"
                  onClick={() => toggleQuality(quality)}
                  className={`p-3 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 flex items-center justify-between gap-1.5 cursor-pointer ${
                    isSelected
                      ? "bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 shadow-md shadow-amber-500/20 ring-2 ring-amber-300 font-bold scale-[1.02]"
                      : "bg-slate-950/80 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-amber-500/40"
                  }`}
                >
                  <span className="truncate">{quality}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 shrink-0 stroke-[3]" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Deep reflection fields matching prompt:
            “Escolha uma qualidade que reconhece em você e uma que gostaria de desenvolver ainda mais.”
        */}
        <div className="pt-6 border-t border-slate-800 space-y-5">
          <div className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
            <Compass className="w-5 h-5 text-amber-400" />
            2. Autorreflexão Pessoal:
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
              <label
                htmlFor="input-qualidade-reconhecida"
                className="block text-xs sm:text-sm font-bold text-amber-300 mb-2"
              >
                Uma qualidade que você reconhece em você:
              </label>
              <textarea
                id="input-qualidade-reconhecida"
                rows={3}
                value={qualityRecognized}
                onChange={(e) => setQualityRecognized(e.target.value)}
                placeholder="Ex: Sou muito amigo(a) e gosto de escutar quando alguém precisa de um ombro..."
                className="w-full p-3 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
              />
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
              <label
                htmlFor="input-qualidade-desenvolver"
                className="block text-xs sm:text-sm font-bold text-blue-300 mb-2"
              >
                Uma qualidade que gostaria de desenvolver ainda mais:
              </label>
              <textarea
                id="input-qualidade-desenvolver"
                rows={3}
                value={qualityToDevelop}
                onChange={(e) => setQualityToDevelop(e.target.value)}
                placeholder="Ex: Gostaria de ter mais paciência com as diferenças e respirar fundo nos momentos difíceis..."
                className="w-full p-3 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
              />
            </div>
          </div>
        </div>

        {error && (
          <div className="mt-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
            {error}
          </div>
        )}

        {/* Navigation Actions */}
        <div className="mt-8 flex items-center justify-between pt-4 border-t border-slate-800">
          <button
            type="button"
            id="btn-voltar-desafio-7"
            onClick={onBack}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-sm transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>← VOLTAR</span>
          </button>

          <button
            type="button"
            id="btn-continuar-desafio-7"
            onClick={handleFinish}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
          >
            <span>CONTINUAR →</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
