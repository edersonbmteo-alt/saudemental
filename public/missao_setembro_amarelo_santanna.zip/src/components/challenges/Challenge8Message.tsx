import React, { useState } from "react";
import { ArrowLeft, Send, Sparkles, Heart, Shield, Lock } from "lucide-react";
import confetti from "canvas-confetti";

interface Challenge8Props {
  onBack: () => void;
  onSubmitMessage: (message: string) => Promise<void>;
  initialMessage?: string;
  isSubmitting?: boolean;
}

export const Challenge8Message: React.FC<Challenge8Props> = ({
  onBack,
  onSubmitMessage,
  initialMessage = "",
  isSubmitting = false,
}) => {
  const [message, setMessage] = useState(initialMessage);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanMsg = message.trim();

    if (!cleanMsg || cleanMsg.length < 10) {
      setError("Por favor, escreva uma mensagem com pelo menos 10 caracteres de carinho ou apoio.");
      return;
    }

    setError(null);

    // Trigger celebration confetti!
    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ["#FBBF24", "#F59E0B", "#FCD34D", "#3B82F6", "#10B981"],
      });
    } catch {
      // Ignored if canvas-confetti environment issue
    }

    await onSubmitMessage(cleanMsg);
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6">
      <div className="rounded-3xl bg-slate-900/90 border border-amber-500/30 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
        {/* Title Header */}
        <div className="flex items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 text-2xl">
              💌
            </div>
            <div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                Desafio 8 de 8 • Etapa Final
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-['Outfit']">
                Mensagem de Força e Esperança
              </h2>
            </div>
          </div>
        </div>

        {/* Prompt description */}
        <div className="mb-6 p-5 rounded-2xl bg-amber-500/10 border border-amber-500/25">
          <p className="text-base sm:text-lg font-bold text-white leading-snug">
            “Escreva uma mensagem que poderia fazer bem a alguém que está passando por um momento difícil. Pode ser uma palavra de esperança, força, carinho ou incentivo.”
          </p>
          <p className="text-xs sm:text-sm text-amber-300/80 mt-2">
            Pense em algo que você gostaria de ouvir quando o dia parece pesado. Sua mensagem será enviada para o <strong>Mural Compartilhado</strong> da escola.
          </p>
        </div>

        {/* Anonymity notice */}
        <div className="mb-6 flex items-center gap-3 px-4 py-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-300">
          <Lock className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            <strong>Privacidade e Acolhimento:</strong> A sua mensagem será exibida no mural de forma estritamente <strong>ANÔNIMA</strong>. O seu nome nunca aparecerá no mural público.
          </span>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit}>
          <div className="relative">
            <textarea
              id="input-mensagem-final"
              rows={6}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Digite aqui a sua mensagem de esperança, carinho e acolhimento para quem puder ler..."
              className="w-full p-4 rounded-2xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-amber-400 leading-relaxed shadow-inner"
            />
            <div className="absolute bottom-3 right-4 text-xs text-slate-500">
              {message.length} caracteres
            </div>
          </div>

          {error && (
            <div className="mt-3 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
              {error}
            </div>
          )}

          {/* Navigation Actions */}
          <div className="mt-8 flex items-center justify-between pt-4 border-t border-slate-800">
            <button
              type="button"
              id="btn-voltar-desafio-8"
              onClick={onBack}
              disabled={isSubmitting}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-sm transition-all cursor-pointer disabled:opacity-50"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>← VOLTAR</span>
            </button>

            <button
              type="submit"
              id="btn-enviar-mural"
              disabled={isSubmitting}
              className="inline-flex items-center gap-2.5 px-7 py-3.5 rounded-xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-extrabold text-sm sm:text-base tracking-wide shadow-xl shadow-amber-500/25 transition-all transform active:scale-95 cursor-pointer disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              <span>{isSubmitting ? "ENVIANDO..." : "CONCLUIR MISSÃO E ENVIAR AO MURAL 🌻"}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
