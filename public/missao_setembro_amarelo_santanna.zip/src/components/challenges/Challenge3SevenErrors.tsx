import React, { useRef, useState, useEffect } from "react";
import { ArrowLeft, ArrowRight, RotateCcw, Sparkles, Pencil, MousePointer, Info } from "lucide-react";

interface Challenge3Props {
  onBack: () => void;
  onContinue: (markedCount: number) => void;
  initialMarkedCount?: number;
}

interface CircleMarker {
  x: number;
  y: number;
  radius: number;
}

export const Challenge3SevenErrors: React.FC<Challenge3Props> = ({
  onBack,
  onContinue,
  initialMarkedCount = 0,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [markers, setMarkers] = useState<CircleMarker[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentCircle, setCurrentCircle] = useState<{ startX: number; startY: number; currentX: number; currentY: number } | null>(null);

  // Redraw canvas whenever markers or currentCircle changes
  const redrawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw saved circles
    markers.forEach((m, idx) => {
      ctx.save();
      ctx.beginPath();
      ctx.arc(m.x, m.y, m.radius, 0, Math.PI * 2);
      ctx.lineWidth = 3.5;
      ctx.strokeStyle = "#F59E0B"; // Amber 500
      ctx.shadowColor = "rgba(245, 158, 11, 0.6)";
      ctx.shadowBlur = 8;
      ctx.stroke();

      // Subtle fill
      ctx.fillStyle = "rgba(245, 158, 11, 0.15)";
      ctx.fill();

      // Small index badge
      ctx.beginPath();
      ctx.arc(m.x - m.radius + 6, m.y - m.radius + 6, 10, 0, Math.PI * 2);
      ctx.fillStyle = "#F59E0B";
      ctx.fill();
      ctx.fillStyle = "#0F172A";
      ctx.font = "bold 11px sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(String(idx + 1), m.x - m.radius + 6, m.y - m.radius + 6);

      ctx.restore();
    });

    // Draw current dragging circle
    if (currentCircle) {
      const radius = Math.max(
        15,
        Math.hypot(
          currentCircle.currentX - currentCircle.startX,
          currentCircle.currentY - currentCircle.startY
        )
      );
      ctx.save();
      ctx.beginPath();
      ctx.arc(currentCircle.startX, currentCircle.startY, radius, 0, Math.PI * 2);
      ctx.lineWidth = 3;
      ctx.strokeStyle = "#FCD34D"; // Yellow 300
      ctx.setLineDash([6, 4]);
      ctx.stroke();
      ctx.fillStyle = "rgba(252, 211, 77, 0.2)";
      ctx.fill();
      ctx.restore();
    }
  };

  // Sync canvas dimensions with image container size
  useEffect(() => {
    const updateSize = () => {
      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (!canvas || !container) return;

      const rect = container.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        canvas.width = rect.width;
        canvas.height = rect.height;
        redrawCanvas();
      }
    };

    updateSize();
    const observer = new ResizeObserver(updateSize);
    if (containerRef.current) observer.observe(containerRef.current);

    return () => observer.disconnect();
  }, [markers]);

  useEffect(() => {
    redrawCanvas();
  }, [markers, currentCircle]);

  // Mouse & Touch Coordinates helper
  const getCoordinates = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    const { x, y } = getCoordinates(e);
    setIsDrawing(true);
    setCurrentCircle({ startX: x, startY: y, currentX: x, currentY: y });
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !currentCircle) return;
    const { x, y } = getCoordinates(e);
    setCurrentCircle((prev) => (prev ? { ...prev, currentX: x, currentY: y } : null));
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !currentCircle) return;
    setIsDrawing(false);

    const radius = Math.max(
      18,
      Math.hypot(
        currentCircle.currentX - currentCircle.startX,
        currentCircle.currentY - currentCircle.startY
      )
    );

    setMarkers((prev) => [
      ...prev,
      { x: currentCircle.startX, y: currentCircle.startY, radius },
    ]);
    setCurrentCircle(null);
  };

  const handleClear = () => {
    setMarkers([]);
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext("2d");
      ctx?.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6">
      <div className="rounded-3xl bg-slate-900/90 border border-amber-500/30 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
        {/* Title Header */}
        <div className="flex items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 text-2xl">
              👀
            </div>
            <div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                Desafio 3 de 8
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-['Outfit']">
                Jogo dos 7 Erros
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-amber-500/10 text-amber-300 border border-amber-500/20">
              Marcações: <strong>{markers.length}</strong>
            </span>
          </div>
        </div>

        {/* Instructions as strictly mandated */}
        <div className="mb-6 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex items-start gap-3 text-amber-200">
          <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="font-bold text-white text-base">
              “Observe a imagem com atenção e marque as diferenças que você encontrar.”
            </p>
            <p className="text-xs text-amber-300/80 mt-1">
              Use o mouse ou o dedo (em telas de toque) para clicar ou arrastar desenhando círculos sobre as diferenças encontradas.
            </p>
          </div>
        </div>

        {/* Actions Bar */}
        <div className="flex items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <MousePointer className="w-3.5 h-3.5 text-amber-400" />
            <span>Clique ou arraste para circular as diferenças</span>
          </div>

          {/* Mandatory Button: LIMPAR MARCAÇÕES */}
          <button
            type="button"
            id="btn-limpar-marcacoes"
            onClick={handleClear}
            disabled={markers.length === 0}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
            <span>LIMPAR MARCAÇÕES</span>
          </button>
        </div>

        {/* Interactive Image & Canvas Stage */}
        <div
          ref={containerRef}
          className="relative w-full overflow-hidden rounded-2xl border-2 border-amber-500/30 bg-slate-950 shadow-2xl select-none touch-none aspect-video"
        >
          {/* Base Image: 7 Erros Illustration */}
          <img
            src="/seven_errors.jpg"
            alt="Jogo dos 7 Erros - Comparação Setembro Amarelo"
            className="w-full h-full object-contain pointer-events-none select-none"
            draggable={false}
          />

          {/* Interactive Drawing Canvas Overlay */}
          <canvas
            ref={canvasRef}
            id="canvas-7-erros"
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            className="absolute inset-0 w-full h-full cursor-crosshair touch-none z-10"
          />
        </div>

        {/* Helpful notice */}
        <div className="mt-4 text-xs text-slate-400 text-center">
          Dica: Você pode marcar quantas diferenças encontrar. Não há limite rígido nem pontuação, o foco é sua observação atenta!
        </div>

        {/* Navigation Actions */}
        <div className="mt-8 flex items-center justify-between pt-4 border-t border-slate-800">
          <button
            type="button"
            id="btn-voltar-desafio-3"
            onClick={onBack}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-sm transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>← VOLTAR</span>
          </button>

          <button
            type="button"
            id="btn-continuar-desafio-3"
            onClick={() => onContinue(markers.length)}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
          >
            <span>CONTINUAR →</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
