import React, { useState } from "react";
import { ArrowLeft, ArrowRight, Heart, Plus, Sparkles, Check, MessageSquare } from "lucide-react";

interface Challenge5Props {
  onBack: () => void;
  onContinue: (selectedWords: string[], reflection: string) => void;
  initialSelected?: string[];
  initialReflection?: string;
}

const DEFAULT_WORDS = [
  "Acolhimento",
  "Amizade",
  "Respeito",
  "Esperança",
  "Cuidado",
  "Escuta",
  "Apoio",
  "Gentileza",
  "Confiança",
  "Empatia",
  "Paciência",
  "Solidariedade",
  "Compreensão",
  "Afeto",
];

export const Challenge5GoodWords: React.FC<Challenge5Props> = ({
  onBack,
  onContinue,
  initialSelected = [],
  initialReflection = "",
}) => {
  const [selectedWords, setSelectedWords] = useState<string[]>(initialSelected);
  const [customWordInput, setCustomWordInput] = useState("");
  const [availableWords, setAvailableWords] = useState<string[]>(DEFAULT_WORDS);
  const [reflection, setReflection] = useState(initialReflection);
  const [error, setError] = useState<string | null>(null);

  const toggleWord = (word: string) => {
    setSelectedWords((prev) =>
      prev.includes(word) ? prev.filter((w) => w !== word) : [...prev, word]
    );
  };

  const handleAddCustomWord = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = customWordInput.trim();
    if (!clean) return;

    if (!availableWords.some((w) => w.toLowerCase() === clean.toLowerCase())) {
      setAvailableWords((prev) => [...prev, clean]);
    }

    if (!selectedWords.some((w) => w.toLowerCase() === clean.toLowerCase())) {
      setSelectedWords((prev) => [...prev, clean]);
    }

    setCustomWordInput("");
  };

  const handleFinish = () => {
    if (selectedWords.length === 0) {
      setError("Por favor, selecione pelo menos uma palavra que faz bem.");
      return;
    }
    if (!reflection.trim() || reflection.trim().length < 10) {
      setError("Por favor, escreva uma breve reflexão explicando a sua escolha (pelo menos 10 caracteres).");
      return;
    }

    setError(null);
    onContinue(selectedWords, reflection.trim());
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6">
      <div className="rounded-3xl bg-slate-900/90 border border-amber-500/30 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
        {/* Title Header */}
        <div className="flex items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 text-2xl">
              💛
            </div>
            <div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                Desafio 5 de 8
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-['Outfit']">
                Palavras que Fazem Bem
              </h2>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs font-semibold text-slate-400">Selecionadas:</span>
            <div className="text-sm font-bold text-amber-400">
              {selectedWords.length}
            </div>
          </div>
        </div>

        <p className="text-sm text-slate-300 mb-6">
          Palavras têm poder: elas podem machucar ou podem curar, acolher e transformar. Escolha as palavras que você considera fundamentais para a valorização da vida e sinta-se à vontade para adicionar novas palavras suas.
        </p>

        {/* Word Chips Selection */}
        <div className="mb-6">
          <label className="block text-xs font-bold text-amber-400 uppercase tracking-wider mb-3">
            1. Escolha ou adicione palavras significativas:
          </label>

          <div className="flex flex-wrap gap-2.5">
            {availableWords.map((word) => {
              const isSelected = selectedWords.includes(word);
              return (
                <button
                  key={word}
                  type="button"
                  onClick={() => toggleWord(word)}
                  className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 flex items-center gap-2 cursor-pointer ${
                    isSelected
                      ? "bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 shadow-md shadow-amber-500/20 ring-2 ring-amber-300 scale-105"
                      : "bg-slate-950/80 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-amber-500/40"
                  }`}
                >
                  {isSelected ? (
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  ) : (
                    <Heart className="w-3 h-3 text-amber-400/60" />
                  )}
                  <span>{word}</span>
                </button>
              );
            })}
          </div>

          {/* Add custom word input */}
          <form onSubmit={handleAddCustomWord} className="mt-4 flex gap-2 max-w-md">
            <input
              type="text"
              value={customWordInput}
              onChange={(e) => setCustomWordInput(e.target.value)}
              placeholder="Adicionar sua própria palavra..."
              className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-semibold text-xs transition-colors border border-slate-700 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Adicionar</span>
            </button>
          </form>
        </div>

        {/* Reflection Textarea as strictly requested */}
        <div className="mt-8 pt-6 border-t border-slate-800">
          <label
            htmlFor="input-palavras-reflexao"
            className="block text-sm sm:text-base font-bold text-white mb-2 flex items-center gap-2"
          >
            <MessageSquare className="w-4 h-4 text-amber-400" />
            2. Entre as palavras que você escolheu, qual considera mais importante para tornar a convivência mais acolhedora? Explique:
          </label>
          <textarea
            id="input-palavras-reflexao"
            rows={4}
            value={reflection}
            onChange={(e) => setReflection(e.target.value)}
            placeholder="Escreva aqui a sua reflexão com suas palavras sinceras..."
            className="w-full p-4 rounded-2xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 leading-relaxed transition-all"
          />
          <div className="flex justify-between items-center text-xs text-slate-400 mt-2 px-1">
            <span>Mínimo de 10 caracteres</span>
            <span>{reflection.length} caracteres</span>
          </div>
        </div>

        {error && (
          <div className="mt-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
            {error}
          </div>
        )}

        {/* Navigation Actions */}
        <div className="mt-8 flex items-center justify-between pt-4 border-t border-slate-800">
          <button
            type="button"
            id="btn-voltar-desafio-5"
            onClick={onBack}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-sm transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>← VOLTAR</span>
          </button>

          <button
            type="button"
            id="btn-continuar-desafio-5"
            onClick={handleFinish}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
          >
            <span>CONTINUAR →</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
