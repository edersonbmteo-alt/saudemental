import React, { useState, useRef, useEffect } from "react";
import { ArrowLeft, ArrowRight, Search, Check, Sparkles, HelpCircle } from "lucide-react";

interface Challenge4Props {
  onBack: () => void;
  onContinue: (foundWords: string[]) => void;
  initialFoundWords?: string[];
}

interface WordLocation {
  word: string;
  cells: { r: number; c: number }[];
  found: boolean;
  color: string;
}

const WORDS_TO_FIND = [
  "EMPATIA",
  "CUIDADO",
  "ESCUTA",
  "AMIZADE",
  "APOIO",
  "RESPEITO",
  "VIDA",
  "ESPERANCA",
  "GENTILEZA",
];

// Grid dimensions 12x12
const GRID_SIZE = 12;

// Verified layout with words in Horizontal, Vertical, Diagonal directions
// 1. ESPERANCA (9) -> Row 0, cols 1..9 (Horizontal)
// 2. GENTILEZA (9) -> Row 2..10, col 11 (Vertical)
// 3. RESPEITO (8) -> Row 2..9, col 2..9 (Diagonal down-right: (2,2) to (9,9))
// 4. EMPATIA (7) -> Row 11, cols 1..7 (Horizontal)
// 5. CUIDADO (7) -> Row 3..9, col 0 (Vertical)
// 6. AMIZADE (7) -> Row 1..7, col 1 (Vertical)
// 7. ESCUTA (6) -> Row 7, cols 3..8 (Horizontal)
// 8. APOIO (5) -> Row 8..4, col 4..8 (Diagonal up-right: (8,4), (7,5), (6,6), (5,7), (4,8))
// 9. VIDA (4) -> Row 4..1, col 10 (Vertical up: (4,10), (3,10), (2,10), (1,10))

const WORD_DEFINITIONS: { word: string; cells: [number, number][] }[] = [
  {
    word: "ESPERANCA",
    cells: [
      [0, 1], [0, 2], [0, 3], [0, 4], [0, 5], [0, 6], [0, 7], [0, 8], [0, 9]
    ]
  },
  {
    word: "AMIZADE",
    cells: [
      [1, 1], [2, 1], [3, 1], [4, 1], [5, 1], [6, 1], [7, 1]
    ]
  },
  {
    word: "RESPEITO",
    cells: [
      [2, 2], [3, 3], [4, 4], [5, 5], [6, 6], [7, 7], [8, 8], [9, 9]
    ]
  },
  {
    word: "CUIDADO",
    cells: [
      [3, 0], [4, 0], [5, 0], [6, 0], [7, 0], [8, 0], [9, 0]
    ]
  },
  {
    word: "ESCUTA",
    cells: [
      [7, 3], [7, 4], [7, 5], [7, 6], [7, 7], [7, 8]
    ]
  },
  {
    word: "APOIO",
    cells: [
      [8, 4], [7, 5], [6, 6], [5, 7], [4, 8]
    ]
  },
  {
    word: "GENTILEZA",
    cells: [
      [2, 11], [3, 11], [4, 11], [5, 11], [6, 11], [7, 11], [8, 11], [9, 11], [10, 11]
    ]
  },
  {
    word: "VIDA",
    cells: [
      [4, 10], [3, 10], [2, 10], [1, 10]
    ]
  },
  {
    word: "EMPATIA",
    cells: [
      [11, 1], [11, 2], [11, 3], [11, 4], [11, 5], [11, 6], [11, 7]
    ]
  }
];

// Word search highlight colors
const WORD_COLORS: Record<string, string> = {
  ESPERANCA: "bg-amber-400 text-slate-950 font-bold ring-2 ring-amber-300",
  AMIZADE: "bg-blue-400 text-slate-950 font-bold ring-2 ring-blue-300",
  RESPEITO: "bg-emerald-400 text-slate-950 font-bold ring-2 ring-emerald-300",
  CUIDADO: "bg-purple-400 text-slate-950 font-bold ring-2 ring-purple-300",
  ESCUTA: "bg-rose-400 text-slate-950 font-bold ring-2 ring-rose-300",
  APOIO: "bg-cyan-400 text-slate-950 font-bold ring-2 ring-cyan-300",
  GENTILEZA: "bg-yellow-400 text-slate-950 font-bold ring-2 ring-yellow-300",
  VIDA: "bg-orange-400 text-slate-950 font-bold ring-2 ring-orange-300",
  EMPATIA: "bg-teal-400 text-slate-950 font-bold ring-2 ring-teal-300",
};

// Build deterministic letter matrix
function buildInitialGrid(): string[][] {
  const grid: string[][] = Array.from({ length: GRID_SIZE }, () =>
    Array(GRID_SIZE).fill("")
  );

  // Fill defined words
  WORD_DEFINITIONS.forEach(({ word, cells }) => {
    cells.forEach(([r, c], i) => {
      grid[r][c] = word[i];
    });
  });

  // Balanced filler letters matching Portuguese phonetics
  const fillers = "ABCDEFGHILMNOPRSTUVZ";
  let seed = 42;
  const randomChar = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return fillers[Math.floor((seed / 233280) * fillers.length)];
  };

  for (let r = 0; r < GRID_SIZE; r++) {
    for (let c = 0; c < GRID_SIZE; c++) {
      if (!grid[r][c]) {
        grid[r][c] = randomChar();
      }
    }
  }

  return grid;
}

const STATIC_GRID = buildInitialGrid();

export const Challenge4WordSearch: React.FC<Challenge4Props> = ({
  onBack,
  onContinue,
  initialFoundWords = [],
}) => {
  const [foundWords, setFoundWords] = useState<string[]>(initialFoundWords);
  const [selectedCells, setSelectedCells] = useState<{ r: number; c: number }[]>([]);
  const [isSelecting, setIsSelecting] = useState(false);
  const [startCell, setStartCell] = useState<{ r: number; c: number } | null>(null);

  // Get straight line of cells between start and end (horizontal, vertical, diagonal)
  const getLineCells = (start: { r: number; c: number }, end: { r: number; c: number }) => {
    const dr = end.r - start.r;
    const dc = end.c - start.c;
    const stepR = dr === 0 ? 0 : dr > 0 ? 1 : -1;
    const stepC = dc === 0 ? 0 : dc > 0 ? 1 : -1;

    // Must be horizontal, vertical or 45-deg diagonal
    if (dr !== 0 && dc !== 0 && Math.abs(dr) !== Math.abs(dc)) {
      return [{ r: start.r, c: start.c }];
    }

    const steps = Math.max(Math.abs(dr), Math.abs(dc));
    const cells: { r: number; c: number }[] = [];

    for (let i = 0; i <= steps; i++) {
      cells.push({
        r: start.r + i * stepR,
        c: start.c + i * stepC,
      });
    }

    return cells;
  };

  const handlePointerDown = (r: number, c: number) => {
    setIsSelecting(true);
    setStartCell({ r, c });
    setSelectedCells([{ r, c }]);
  };

  const handlePointerEnter = (r: number, c: number) => {
    if (!isSelecting || !startCell) return;
    const line = getLineCells(startCell, { r, c });
    setSelectedCells(line);
  };

  const handlePointerUp = () => {
    if (!isSelecting) return;
    setIsSelecting(false);

    // Form selected word
    const selectedLetters = selectedCells.map((cell) => STATIC_GRID[cell.r][cell.c]).join("");
    const reversedLetters = selectedLetters.split("").reverse().join("");

    // Check if matched
    const matchedDef = WORD_DEFINITIONS.find(
      (w) => w.word === selectedLetters || w.word === reversedLetters
    );

    if (matchedDef && !foundWords.includes(matchedDef.word)) {
      setFoundWords((prev) => [...prev, matchedDef.word]);
    }

    setSelectedCells([]);
    setStartCell(null);
  };

  // Helper to check if a cell belongs to any found word
  const getFoundColorForCell = (r: number, c: number): string | null => {
    for (const def of WORD_DEFINITIONS) {
      if (foundWords.includes(def.word)) {
        if (def.cells.some(([cr, cc]) => cr === r && cc === c)) {
          return WORD_COLORS[def.word] || "bg-amber-400 text-slate-950 font-bold";
        }
      }
    }
    return null;
  };

  const isCellSelected = (r: number, c: number) =>
    selectedCells.some((cell) => cell.r === r && cell.c === c);

  return (
    <div
      className="w-full max-w-5xl mx-auto px-4 py-6 select-none"
      onPointerUp={handlePointerUp}
    >
      <div className="rounded-3xl bg-slate-900/90 border border-amber-500/30 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
        {/* Title Header */}
        <div className="flex items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 text-2xl">
              🔎
            </div>
            <div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                Desafio 4 de 8
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-['Outfit']">
                Caça-Palavras da Empatia
              </h2>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs font-semibold text-slate-400">Encontradas:</span>
            <div className="text-sm font-bold text-amber-400">
              {foundWords.length} de {WORDS_TO_FIND.length}
            </div>
          </div>
        </div>

        <p className="text-sm text-slate-300 mb-6">
          Encontre na grade as 9 palavras essenciais para o cultivo da empatia e valorização da vida. Elas podem estar na <strong>horizontal</strong>, <strong>vertical</strong> ou <strong>diagonal</strong>. Clique e arraste para selecionar!
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Interactive Word Search Grid (12x12) */}
          <div className="lg:col-span-8 flex justify-center">
            <div className="p-3 sm:p-4 rounded-2xl bg-slate-950 border-2 border-amber-500/30 shadow-inner max-w-full overflow-x-auto">
              <div
                className="grid gap-1.5 touch-none"
                style={{
                  gridTemplateColumns: `repeat(${GRID_SIZE}, minmax(0, 1fr))`,
                  width: "min(100%, 460px)",
                }}
              >
                {STATIC_GRID.map((row, r) =>
                  row.map((letter, c) => {
                    const foundClass = getFoundColorForCell(r, c);
                    const isSelected = isCellSelected(r, c);

                    return (
                      <button
                        key={`${r}-${c}`}
                        type="button"
                        onPointerDown={() => handlePointerDown(r, c)}
                        onPointerEnter={() => handlePointerEnter(r, c)}
                        className={`aspect-square w-full rounded-lg flex items-center justify-center font-mono text-xs sm:text-sm md:text-base font-bold transition-colors select-none cursor-pointer ${
                          isSelected
                            ? "bg-yellow-400 text-slate-950 ring-2 ring-yellow-300 scale-105 z-10 shadow-md"
                            : foundClass
                            ? `${foundClass} scale-[1.02] shadow-sm`
                            : "bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800/80"
                        }`}
                      >
                        {letter}
                      </button>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* Word List Checklist */}
          <div className="lg:col-span-4 space-y-3">
            <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
              <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <Search className="w-3.5 h-3.5" />
                Palavras a Encontrar ({foundWords.length}/{WORDS_TO_FIND.length})
              </h3>

              <div className="grid grid-cols-2 lg:grid-cols-1 gap-2">
                {WORDS_TO_FIND.map((word) => {
                  const isFound = foundWords.includes(word);
                  return (
                    <div
                      key={word}
                      className={`flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                        isFound
                          ? "bg-amber-500/15 border border-amber-500/40 text-amber-200 line-through opacity-80"
                          : "bg-slate-900 border border-slate-800 text-slate-300"
                      }`}
                    >
                      <span>{word}</span>
                      {isFound ? (
                        <Check className="w-3.5 h-3.5 text-amber-400" />
                      ) : (
                        <span className="w-2 h-2 rounded-full bg-slate-700" />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Hint Box */}
            <div className="p-3.5 rounded-xl bg-blue-950/30 border border-blue-500/20 text-blue-200 text-xs flex items-start gap-2">
              <HelpCircle className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
              <div>
                <span>Procure também em diagonais e de baixo para cima! Você pode continuar a qualquer momento quando sentir que encontrou o suficiente.</span>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Actions */}
        <div className="mt-8 flex items-center justify-between pt-4 border-t border-slate-800">
          <button
            type="button"
            id="btn-voltar-desafio-4"
            onClick={onBack}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-sm transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>← VOLTAR</span>
          </button>

          <button
            type="button"
            id="btn-continuar-desafio-4"
            onClick={() => onContinue(foundWords)}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
          >
            <span>CONTINUAR →</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
