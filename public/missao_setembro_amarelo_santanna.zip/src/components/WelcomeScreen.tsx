import React, { useState } from "react";
import { ArrowRight, Compass, Heart, Shield, Sparkles, Users } from "lucide-react";

interface WelcomeScreenProps {
  onStartMission: (name: string, className: string) => Promise<void>;
  loading?: boolean;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  onStartMission,
  loading = false,
}) => {
  const [name, setName] = useState("");
  const [className, setClassName] = useState("");
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();
    const trimmedClass = className.trim();

    if (!trimmedName) {
      setError("Por favor, digite seu nome para iniciar a missão.");
      return;
    }
    if (!trimmedClass) {
      setError("Por favor, informe sua turma (ex: 61, 72, 8A, etc.).");
      return;
    }

    setError(null);
    try {
      await onStartMission(trimmedName, trimmedClass);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro ao iniciar a missão.";
      setError(msg);
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto px-4 py-8 sm:py-12">
      {/* Intro Card */}
      <div className="relative overflow-hidden rounded-3xl bg-slate-900/90 border border-amber-500/30 p-6 sm:p-10 shadow-2xl shadow-amber-950/40 backdrop-blur-xl">
        {/* Subtle decorative glow */}
        <div className="absolute -top-24 -right-24 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Badge & Title */}
        <div className="text-center max-w-xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-xs font-semibold tracking-wide uppercase mb-4">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            Jornada Educativa de Valorização da Vida
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-['Outfit'] tracking-tight leading-tight">
            Bem-vindo(a) à{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-amber-400 to-yellow-500">
              Missão Setembro Amarelo
            </span>{" "}
            🌻
          </h2>

          <p className="mt-4 text-sm sm:text-base text-slate-300 leading-relaxed">
            Nesta experiência interativa, você passará por <strong>8 desafios reflexivos</strong>{" "}
            sobre empatia, escuta acolhedora, respeito às diferenças e cuidado com quem está ao nosso redor.
          </p>
        </div>

        {/* Feature Highlights (clean, not childish) */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Compass className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-semibold text-white">8 Atividades</div>
              <div className="text-[11px] text-slate-400">Vídeo, quiz, jogos & reflexão</div>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="w-9 h-9 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
              <Heart className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-semibold text-white">Espaço Seguro</div>
              <div className="text-[11px] text-slate-400">Pensar, sentir e compartilhar</div>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-semibold text-white">Mural Compartilhado</div>
              <div className="text-[11px] text-slate-400">Mensagens anônimas de força</div>
            </div>
          </div>
        </div>

        {/* Form to Start */}
        <form onSubmit={handleSubmit} className="mt-8 pt-6 border-t border-slate-800">
          <div className="text-center mb-6">
            <h3 className="text-base font-bold text-white flex items-center justify-center gap-2">
              <Shield className="w-4 h-4 text-amber-400" />
              Identifique-se para começar
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Informe seu nome e turma para que o professor possa acompanhar sua participação.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-md mx-auto">
            <div>
              <label
                htmlFor="input-student-name"
                className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider"
              >
                Nome Completo
              </label>
              <input
                id="input-student-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Maria Eduarda"
                autoComplete="name"
                required
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-all"
              />
            </div>

            <div>
              <label
                htmlFor="input-student-class"
                className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider"
              >
                Turma
              </label>
              <input
                id="input-student-class"
                type="text"
                value={className}
                onChange={(e) => setClassName(e.target.value)}
                placeholder="Ex: 61, 72, 8A..."
                required
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-all"
              />
            </div>
          </div>

          {error && (
            <div className="mt-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs text-center max-w-md mx-auto">
              {error}
            </div>
          )}

          {/* Primary Action Button: COMEÇAR MISSÃO */}
          <div className="mt-8 flex justify-center">
            <button
              type="submit"
              id="btn-comecar-missao"
              disabled={loading}
              className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:via-yellow-300 hover:to-amber-400 text-slate-950 font-extrabold text-base tracking-wide shadow-xl shadow-amber-500/25 transition-all duration-300 transform active:scale-95 disabled:opacity-50 cursor-pointer"
            >
              <span>{loading ? "INICIANDO..." : "COMEÇAR MISSÃO"}</span>
              <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
