import React from "react";
import { Check } from "lucide-react";

interface ProgressBarProps {
  currentStep: number;
  totalSteps: number;
  stepTitles: string[];
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  currentStep,
  totalSteps,
  stepTitles,
}) => {
  const percentage = Math.round((currentStep / totalSteps) * 100);

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-4 mb-6">
      {/* Top indicator: Desafio X de 8 */}
      <div className="flex items-center justify-between gap-4 mb-2">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center justify-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30">
            Desafio {currentStep} de {totalSteps}
          </span>
          <span className="text-sm font-semibold text-slate-200 hidden sm:inline">
            {stepTitles[currentStep - 1] || ""}
          </span>
        </div>
        <div className="text-xs font-mono font-medium text-amber-400">
          {percentage}% Concluído
        </div>
      </div>

      {/* Progress Track */}
      <div className="relative w-full h-2.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
        <div
          className="h-full bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-300 transition-all duration-500 ease-out rounded-full shadow-[0_0_12px_rgba(251,191,36,0.4)]"
          style={{ width: `${percentage}%` }}
        />
      </div>

      {/* Step Dots with Icons */}
      <div className="flex justify-between items-center mt-3 px-1">
        {Array.from({ length: totalSteps }, (_, i) => {
          const stepNum = i + 1;
          const isDone = stepNum < currentStep;
          const isCurrent = stepNum === currentStep;

          return (
            <div
              key={stepNum}
              className="flex flex-col items-center group relative"
              title={`Desafio ${stepNum}: ${stepTitles[i]}`}
            >
              <div
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 ${
                  isDone
                    ? "bg-amber-500 text-slate-950 ring-2 ring-amber-400/40"
                    : isCurrent
                    ? "bg-yellow-400 text-slate-950 font-extrabold ring-4 ring-yellow-400/30 scale-110 shadow-lg shadow-amber-500/30"
                    : "bg-slate-800 text-slate-400 border border-slate-700"
                }`}
              >
                {isDone ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : stepNum}
              </div>
              <span className="text-[10px] text-slate-400 mt-1 hidden md:block max-w-[70px] truncate text-center">
                {stepTitles[i]?.split(" ")[0]}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
