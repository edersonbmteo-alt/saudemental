import React, { useState, useEffect } from "react";
import {
  X,
  Lock,
  Download,
  Search,
  Filter,
  Users,
  CheckCircle2,
  FileSpreadsheet,
  Trash2,
  RefreshCw,
  BookOpen,
  Info,
  ExternalLink,
} from "lucide-react";
import { StudentDataRecord } from "../types";
import { api } from "../services/api";

interface TeacherModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TeacherModal: React.FC<TeacherModalProps> = ({ isOpen, onClose }) => {
  const [token, setToken] = useState<string | null>(
    sessionStorage.getItem("teacher_token")
  );
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState<string | null>(null);
  const [students, setStudents] = useState<StudentDataRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedClass, setSelectedClass] = useState("TODAS");
  const [activeTab, setActiveTab] = useState<"students" | "instructions">("students");
  const [selectedStudentDetail, setSelectedStudentDetail] = useState<StudentDataRecord | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoading(true);

    try {
      const res = await api.teacherLogin(code, password);
      if (res.success && res.token) {
        setToken(res.token);
        sessionStorage.setItem("teacher_token", res.token);
        loadStudents(res.token);
      } else {
        setLoginError(res.error || "Código ou Senha incorretos.");
      }
    } catch {
      setLoginError("Erro na conexão com o servidor.");
    } finally {
      setLoading(false);
    }
  };

  const loadStudents = async (authToken: string) => {
    setLoading(true);
    try {
      const data = await api.getTeacherStudents(authToken);
      setStudents(data);
    } catch {
      setToken(null);
      sessionStorage.removeItem("teacher_token");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && token) {
      loadStudents(token);
    }
  }, [isOpen, token]);

  const handleLogout = () => {
    setToken(null);
    sessionStorage.removeItem("teacher_token");
  };

  const handleExportCsv = () => {
    if (!token) return;
    window.location.href = `/api/teacher/export-csv?token=${encodeURIComponent(token)}`;
  };

  const handleClearData = async () => {
    if (!token) return;
    const confirm = window.confirm(
      "Atenção: Tem certeza que deseja apagar todas as respostas dos estudantes? Esta ação não pode ser desfeita."
    );
    if (!confirm) return;

    try {
      await api.clearTeacherData(token);
      setStudents([]);
    } catch {
      alert("Erro ao limpar dados.");
    }
  };

  if (!isOpen) return null;

  // Filter students
  const classesList = Array.from(new Set(students.map((s) => s.studentClass))).filter(Boolean);
  const filteredStudents = students.filter((s) => {
    const matchSearch =
      s.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.studentClass.toLowerCase().includes(searchQuery.toLowerCase());
    const matchClass = selectedClass === "TODAS" || s.studentClass === selectedClass;
    return matchSearch && matchClass;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-6xl max-h-[92vh] flex flex-col rounded-3xl bg-slate-900 border border-amber-500/30 shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Área do Professor
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-normal">
                  Prof. Ederson Braga Mello
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Colégio Franciscano Sant’Anna • Santa Maria – RS
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {token && (
              <button
                type="button"
                onClick={handleLogout}
                className="text-xs text-slate-400 hover:text-rose-400 px-3 py-1.5 rounded-lg border border-slate-700 hover:border-rose-500/40 transition-colors"
              >
                Sair
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Content */}
        {!token ? (
          /* Login Form */
          <div className="p-8 max-w-md mx-auto my-auto w-full">
            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto mb-3">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">Acesso Exclusivo do Professor</h3>
              <p className="text-xs text-slate-400 mt-1">
                Insira as credenciais institucionais para visualizar as respostas.
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Código de Acesso
                </label>
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="Código (ex: EDERSON)"
                  required
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Senha
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Senha"
                  required
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
                />
              </div>

              {loginError && (
                <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
                  {loginError}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-amber-500/20 transition-all cursor-pointer disabled:opacity-50"
              >
                {loading ? "Verificando..." : "ENTRAR NA ÁREA DO PROFESSOR"}
              </button>
            </form>
          </div>
        ) : (
          /* Teacher Dashboard */
          <div className="flex-1 flex flex-col overflow-hidden p-6">
            {/* Top Stats & Tabs */}
            <div className="flex flex-wrap items-center justify-between gap-4 mb-5">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab("students")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    activeTab === "students"
                      ? "bg-amber-400 text-slate-950 shadow-md shadow-amber-500/20"
                      : "bg-slate-800 text-slate-300 hover:text-white"
                  }`}
                >
                  Respostas dos Estudantes ({students.length})
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab("instructions")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    activeTab === "instructions"
                      ? "bg-amber-400 text-slate-950 shadow-md shadow-amber-500/20"
                      : "bg-slate-800 text-slate-300 hover:text-white"
                  }`}
                >
                  Configuração de Rede & Banco de Dados
                </button>
              </div>

              {activeTab === "students" && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => token && loadStudents(token)}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1.5 border border-slate-700 cursor-pointer"
                    title="Recarregar"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
                  </button>

                  <button
                    type="button"
                    id="btn-exportar-csv"
                    onClick={handleExportCsv}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
                  >
                    <FileSpreadsheet className="w-4 h-4" />
                    <span>EXPORTAR CSV</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleClearData}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-rose-950/60 text-slate-400 hover:text-rose-300 text-xs border border-slate-700 hover:border-rose-500/30 cursor-pointer"
                    title="Limpar todos os dados"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {activeTab === "students" ? (
              <>
                {/* Search and Filters */}
                <div className="flex flex-col sm:flex-row gap-3 mb-4">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Buscar por nome do estudante..."
                      className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-400"
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    <Filter className="w-4 h-4 text-slate-400" />
                    <select
                      value={selectedClass}
                      onChange={(e) => setSelectedClass(e.target.value)}
                      className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:ring-1 focus:ring-amber-400"
                    >
                      <option value="TODAS">Todas as Turmas</option>
                      {classesList.map((c) => (
                        <option key={c} value={c}>
                          Turma {c}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Table as strictly requested by prompt:
                    | Estudante | Turma | Quiz | Palavras | Cruzadinha | Qualidades | Reflexão | Mensagem | Conclusão |
                */}
                <div className="flex-1 overflow-x-auto overflow-y-auto border border-slate-800 rounded-2xl bg-slate-950/70">
                  <table className="w-full text-left text-xs text-slate-300">
                    <thead className="sticky top-0 bg-slate-950 text-slate-400 uppercase text-[11px] font-bold tracking-wider border-b border-slate-800 z-10">
                      <tr>
                        <th className="py-3 px-4">Estudante</th>
                        <th className="py-3 px-3">Turma</th>
                        <th className="py-3 px-3">Quiz</th>
                        <th className="py-3 px-3">Palavras</th>
                        <th className="py-3 px-3">Cruzadinha</th>
                        <th className="py-3 px-3">Qualidades</th>
                        <th className="py-3 px-3">Reflexão</th>
                        <th className="py-3 px-3">Mensagem</th>
                        <th className="py-3 px-4">Conclusão</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/80">
                      {filteredStudents.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="py-12 text-center text-slate-500">
                            Nenhum estudante registrado ainda.
                          </td>
                        </tr>
                      ) : (
                        filteredStudents.map((s) => (
                          <tr
                            key={s.id}
                            onClick={() => setSelectedStudentDetail(s)}
                            className="hover:bg-slate-900/80 transition-colors cursor-pointer"
                          >
                            <td className="py-3 px-4 font-bold text-white whitespace-nowrap">
                              {s.studentName}
                            </td>
                            <td className="py-3 px-3 font-mono font-semibold text-amber-300 whitespace-nowrap">
                              {s.studentClass}
                            </td>
                            <td className="py-3 px-3 whitespace-nowrap">
                              <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-200">
                                {s.quizScore || "Pendente"}
                              </span>
                            </td>
                            <td className="py-3 px-3 whitespace-nowrap">
                              {s.wordSearchFound?.length || 0} palavras
                            </td>
                            <td className="py-3 px-3 whitespace-nowrap">
                              {s.crosswordResult || "Pendente"}
                            </td>
                            <td className="py-3 px-3 max-w-[150px] truncate" title={s.qualitiesSelected?.join(", ")}>
                              {s.qualitiesSelected?.length
                                ? `${s.qualitiesSelected.length} selecionadas`
                                : "-"}
                            </td>
                            <td className="py-3 px-3 max-w-[180px] truncate" title={s.wordsGoodReflection}>
                              {s.wordsGoodReflection || "-"}
                            </td>
                            <td className="py-3 px-3 max-w-[180px] truncate italic" title={s.finalMessage}>
                              {s.finalMessage ? `“${s.finalMessage}”` : "-"}
                            </td>
                            <td className="py-3 px-4 whitespace-nowrap">
                              {s.completed ? (
                                <span className="inline-flex items-center gap-1 text-emerald-400 font-semibold">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  Concluído
                                </span>
                              ) : (
                                <span className="text-amber-400">
                                  Desafio {s.currentStep}/8
                                </span>
                              )}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="mt-2 text-[11px] text-slate-400 text-right">
                  Dica: Clique em qualquer linha para ver as respostas completas e detalhadas do estudante.
                </div>
              </>
            ) : (
              /* Network & Database Instructions tab */
              <div className="flex-1 overflow-y-auto space-y-6 text-sm text-slate-300 pr-2">
                <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-200">
                  <h4 className="font-bold text-base text-white flex items-center gap-2 mb-2">
                    <Info className="w-5 h-5 text-amber-400" />
                    Como o Sistema Funciona no Laboratório de Informática
                  </h4>
                  <p className="leading-relaxed">
                    Este aplicativo roda como um servidor completo full-stack. Todos os computadores do laboratório que acessarem o link da aplicação estão conectados <strong>ao mesmo servidor central</strong>.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                    <h5 className="font-bold text-white mb-2 flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center text-xs">
                        1
                      </span>
                      Armazenamento em Tempo Real
                    </h5>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      As respostas dos estudantes e as mensagens do mural são salvas no disco do servidor em arquivos JSON estruturados. Isso permite que Computador 1, 2, 3 vejam o mesmo mural instantaneamente sem conflitos e sem depender de localStorage individual.
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                    <h5 className="font-bold text-white mb-2 flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs">
                        2
                      </span>
                      Exportação para Excel / Planilhas
                    </h5>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Ao clicar no botão <strong>EXPORTAR CSV</strong>, o servidor gera um arquivo com codificação UTF-8 BOM, garantindo que acentos e caracteres em português (como ç, ã, é) abram perfeitamente no Excel e no Google Sheets.
                    </p>
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                  <h5 className="font-bold text-white">Opções de Nuvem Externa (Opcional):</h5>
                  <ul className="list-disc list-inside space-y-2 text-xs text-slate-400">
                    <li>
                      <strong className="text-slate-200">Google Sheets + Apps Script:</strong> Caso o professor queira que cada resposta caia direto em uma planilha sua no Google Drive, basta criar um formulário Google Apps Script Webhook. O servidor já suporta encaminhar cada requisição para uma URL de webhook.
                    </li>
                    <li>
                      <strong className="text-slate-200">Firebase / Supabase:</strong> Podem ser ativados com chaves gratuitas na aba de configurações caso a escola utilize autenticação com contas institucionais do Google Workspace.
                    </li>
                  </ul>
                </div>

                {/* Package ZIP Download */}
                <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-500/10 via-yellow-500/10 to-amber-500/5 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div>
                    <h5 className="font-bold text-white text-sm flex items-center gap-2">
                      <span>📦</span>
                      Pacote Completo do Projeto (.ZIP)
                    </h5>
                    <p className="text-xs text-slate-300 mt-1">
                      Baixe o código fonte integral do projeto, arquivos estáticos e imagens para backup ou execução local.
                    </p>
                  </div>
                  <a
                    href="/missao_setembro_amarelo_santanna.zip"
                    download="missao_setembro_amarelo_santanna.zip"
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-xs tracking-wide shadow-md transition-all whitespace-nowrap cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>BAIXAR PACOTE .ZIP</span>
                  </a>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Student Detail Modal */}
        {selectedStudentDetail && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <div className="relative w-full max-w-2xl max-h-[85vh] overflow-y-auto rounded-3xl bg-slate-900 border border-amber-500/40 p-6 shadow-2xl">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                <div>
                  <h3 className="text-lg font-bold text-white">
                    {selectedStudentDetail.studentName}
                  </h3>
                  <span className="text-xs font-mono text-amber-400">
                    Turma: {selectedStudentDetail.studentClass}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedStudentDetail(null)}
                  className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-4 text-xs">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="font-bold text-amber-400 block mb-1">🧠 Quiz:</span>
                  <div>{selectedStudentDetail.quizScore}</div>
                  <div className="text-slate-400 mt-1">{selectedStudentDetail.quizDetails}</div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="font-bold text-amber-400 block mb-1">
                    🔎 Caça-Palavras e Cruzadinha:
                  </span>
                  <div>Palavras encontradas: {selectedStudentDetail.wordSearchFound?.join(", ") || "Nenhuma"}</div>
                  <div className="mt-1">Cruzadinha: {selectedStudentDetail.crosswordResult}</div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="font-bold text-amber-400 block mb-1">
                    💛 Reflexão de Palavras:
                  </span>
                  <div className="text-slate-200">{selectedStudentDetail.wordsGoodReflection || "Não preenchido"}</div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="font-bold text-amber-400 block mb-1">
                    🌟 Qualidades Reconhecidas:
                  </span>
                  <div>Reconhecidas: {selectedStudentDetail.qualitiesSelected?.join(", ") || "Nenhuma"}</div>
                  <div className="mt-1">
                    <strong>Própria:</strong> {selectedStudentDetail.qualityRecognizedOwn || "-"}
                  </div>
                  <div className="mt-1">
                    <strong>A Desenvolver:</strong> {selectedStudentDetail.qualityToDevelop || "-"}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="font-bold text-amber-400 block mb-1">
                    💌 Mensagem Anônima Enviada ao Mural:
                  </span>
                  <div className="italic text-slate-200">
                    “{selectedStudentDetail.finalMessage || "Não preenchido"}”
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
