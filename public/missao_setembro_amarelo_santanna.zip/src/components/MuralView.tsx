import React, { useState, useEffect } from "react";
import {
  Sparkles,
  RefreshCw,
  Send,
  Heart,
  Award,
  Calendar,
  Lock,
  MessageCircle,
  Share2,
  CheckCircle2,
} from "lucide-react";
import { SharedMessage } from "../types";
import { api } from "../services/api";

interface MuralViewProps {
  studentName?: string;
  studentClass?: string;
  onRestartNewStudent: () => void;
}

export const MuralView: React.FC<MuralViewProps> = ({
  studentName,
  studentClass,
  onRestartNewStudent,
}) => {
  const [messages, setMessages] = useState<SharedMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [newMsgText, setNewMsgText] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [showCertificateModal, setShowCertificateModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Fetch messages from server
  const fetchMessages = async (silent = false) => {
    if (!silent) setRefreshing(true);
    try {
      const data = await api.getMessages();
      setMessages(data);
    } catch (err) {
      console.error("Error fetching mural messages:", err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Initial load + Polling every 5 seconds so any computer in the lab syncs!
  useEffect(() => {
    fetchMessages();
    const interval = setInterval(() => {
      fetchMessages(true);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleLike = async (id: string) => {
    // Optimistic update
    setMessages((prev) =>
      prev.map((m) => (m.id === id ? { ...m, likes: (m.likes || 0) + 1 } : m))
    );
    await api.likeMessage(id);
  };

  const handleSendExtraMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMsgText.trim() || newMsgText.trim().length < 5) return;

    setIsSending(true);
    const added = await api.postMessage(newMsgText.trim());
    if (added) {
      setMessages((prev) => [added, ...prev]);
      setNewMsgText("");
    }
    setIsSending(false);
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-8">
      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-3xl bg-slate-900/90 border border-amber-500/30 p-6 sm:p-10 shadow-2xl backdrop-blur-xl mb-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-xs font-bold tracking-wide uppercase mb-3">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              Mural da Esperança e Valorização da Vida
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-['Outfit'] flex items-center gap-2">
              🌻 MURAL DE MENSAGENS
            </h1>
            <p className="mt-2 text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
              Todas as mensagens compartilhadas pelos estudantes dos computadores do laboratório reunidas em um só lugar. Aqui cada palavra acolhe, inspira e lembra que ninguém está sozinho!
            </p>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {studentName && (
              <button
                type="button"
                id="btn-ver-certificado"
                onClick={() => setShowCertificateModal(true)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs sm:text-sm font-semibold transition-all cursor-pointer"
              >
                <Award className="w-4 h-4 text-amber-400" />
                <span>Meu Certificado</span>
              </button>
            )}

            <button
              type="button"
              id="btn-atualizar-mural"
              onClick={() => fetchMessages()}
              disabled={refreshing}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-semibold border border-slate-700 transition-all cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 text-amber-400 ${refreshing ? "animate-spin" : ""}`} />
              <span>{refreshing ? "Atualizando..." : "Atualizar Mural"}</span>
            </button>
          </div>
        </div>

        {/* Live sync banner */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Sincronização em tempo real ativa entre todos os computadores da escola</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-400">
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span>Todas as mensagens são exibidas de forma 100% anônima</span>
          </div>
        </div>
      </div>

      {/* Write extra message card */}
      <div className="mb-8 p-5 sm:p-6 rounded-2xl bg-slate-900/70 border border-slate-800">
        <form onSubmit={handleSendExtraMessage}>
          <label
            htmlFor="input-extra-message"
            className="block text-xs font-bold text-amber-400 uppercase tracking-wider mb-2 flex items-center gap-1.5"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            Deseja deixar mais uma mensagem anônima no mural?
          </label>
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              id="input-extra-message"
              type="text"
              value={newMsgText}
              onChange={(e) => setNewMsgText(e.target.value)}
              placeholder="Escreva uma palavra de carinho ou esperança..."
              className="flex-1 px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
            <button
              type="submit"
              disabled={isSending || newMsgText.trim().length < 5}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-bold text-sm tracking-wide shadow-md shadow-amber-500/20 transition-all disabled:opacity-50 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>{isSending ? "Enviando..." : "Publicar no Mural"}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Messages Grid */}
      {loading ? (
        <div className="py-16 text-center text-slate-400 flex flex-col items-center gap-3">
          <div className="w-8 h-8 rounded-full border-2 border-amber-400 border-t-transparent animate-spin" />
          <span>Carregando mensagens do mural...</span>
        </div>
      ) : messages.length === 0 ? (
        <div className="py-16 text-center text-slate-400 bg-slate-900/40 rounded-3xl border border-slate-800">
          <span className="text-4xl mb-2 block">🌻</span>
          <p className="text-base font-semibold text-white">Nenhuma mensagem publicada ainda.</p>
          <p className="text-xs text-slate-400 mt-1">Seja o primeiro a enviar uma palavra acolhedora!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {messages.map((msg, index) => (
            <div
              key={msg.id || index}
              className="group relative flex flex-col justify-between p-6 rounded-2xl bg-slate-900/80 hover:bg-slate-900 border border-amber-500/20 hover:border-amber-400/50 transition-all duration-300 shadow-lg hover:shadow-amber-500/10"
            >
              {/* Top card adornment */}
              <div className="flex items-center justify-between gap-2 mb-4">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-amber-400/10 text-amber-300 border border-amber-400/20">
                  <span>🌻</span>
                  <span>Estudante Sant’Anna</span>
                </span>
                <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                  <Calendar className="w-3 h-3 text-slate-400" />
                  {msg.timestamp
                    ? new Date(msg.timestamp).toLocaleTimeString("pt-BR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })
                    : ""}
                </span>
              </div>

              {/* Message text */}
              <p className="text-sm sm:text-base text-slate-200 leading-relaxed font-medium mb-6 italic">
                “{msg.message}”
              </p>

              {/* Bottom Card Footer: Sunflower Like */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-800/80">
                <span className="text-xs text-slate-400 font-semibold">Valorização da Vida</span>
                <button
                  type="button"
                  onClick={() => handleLike(msg.id)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-950 hover:bg-amber-500/20 border border-slate-800 hover:border-amber-400/40 text-xs font-semibold text-amber-300 transition-all cursor-pointer group-hover:scale-105"
                  title="Enviar um girassol de apoio"
                >
                  <span className="text-sm">🌻</span>
                  <span>{msg.likes || 0}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Restart Mission for new student */}
      <div className="mt-12 text-center pt-8 border-t border-slate-800">
        <button
          type="button"
          onClick={onRestartNewStudent}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs sm:text-sm font-semibold border border-slate-700 transition-all cursor-pointer"
        >
          <span>Iniciar com outro estudante / nova turma</span>
        </button>
      </div>

      {/* Certificate Modal */}
      {showCertificateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border-2 border-amber-500/40 p-6 sm:p-8 shadow-2xl text-center">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-3xl mx-auto mb-4 shadow-lg shadow-amber-500/20">
              🌻
            </div>

            <div className="text-xs font-bold text-amber-400 uppercase tracking-widest mb-1">
              Colégio Franciscano Sant’Anna • Santa Maria – RS
            </div>

            <h3 className="text-2xl font-extrabold text-white font-['Outfit']">
              Certificado de Conclusão
            </h3>

            <p className="mt-3 text-sm text-slate-300 leading-relaxed">
              Certificamos com alegria que o(a) estudante:
            </p>

            <div className="my-4 p-4 rounded-2xl bg-slate-950 border border-amber-500/30">
              <div className="text-xl font-bold text-amber-300">{studentName}</div>
              <div className="text-xs text-slate-400 mt-0.5">Turma: {studentClass}</div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Concluiu com dedicação os <strong>8 Desafios da Missão Setembro Amarelo</strong>, promovendo a empatia, o acolhimento, o respeito mútuo e a valorização da vida.
            </p>

            <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400">
              Orientador: <strong>Prof. Ederson Braga Mello</strong>
            </div>

            <div className="mt-6 flex justify-center gap-3">
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs cursor-pointer"
              >
                Imprimir / Salvar PDF
              </button>
              <button
                type="button"
                onClick={() => setShowCertificateModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
