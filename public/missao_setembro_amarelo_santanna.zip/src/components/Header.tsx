import React from "react";
import { ShieldCheck, UserCheck, Sparkles } from "lucide-react";
import { StudentSession } from "../types";

interface HeaderProps {
  session: StudentSession | null;
  onOpenTeacher: () => void;
  onResetSession?: () => void;
  onGoToMural?: () => void;
  showMuralButton?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  session,
  onOpenTeacher,
  onResetSession,
  onGoToMural,
  showMuralButton = false,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-amber-500/20 bg-slate-950/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
        {/* Project Branding */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 via-amber-500 to-yellow-600 flex items-center justify-center text-xl shadow-lg shadow-amber-500/20 ring-2 ring-amber-400/30 select-none">
            🌻
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-extrabold tracking-tight text-white font-['Outfit'] flex items-center gap-1.5">
                MISSÃO SETEMBRO AMARELO
                <span className="text-amber-400">🌻</span>
              </h1>
            </div>
            <p className="text-xs text-slate-400 flex items-center gap-1.5 flex-wrap">
              <span className="font-semibold text-amber-300/90">Colégio Franciscano Sant’Anna</span>
              <span className="text-slate-600">•</span>
              <span className="text-slate-300">Santa Maria – RS</span>
              <span className="text-slate-600">•</span>
              <span className="text-slate-400">Prof. Ederson Braga Mello</span>
            </p>
          </div>
        </div>

        {/* Action Controls & Session Badge */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          {session && (
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-amber-500/30 text-xs">
              <UserCheck className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-semibold text-white">{session.name}</span>
              <span className="text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded text-[11px] font-mono">
                {session.className}
              </span>
              {onResetSession && (
                <button
                  type="button"
                  onClick={onResetSession}
                  className="text-slate-500 hover:text-rose-400 transition-colors ml-1 text-[11px]"
                  title="Trocar estudante / reiniciar"
                >
                  (Sair)
                </button>
              )}
            </div>
          )}

          {showMuralButton && onGoToMural && (
            <button
              type="button"
              onClick={onGoToMural}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-medium transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Ver Mural 🌻</span>
            </button>
          )}

          {/* Discreet Teacher Area Button */}
          <button
            type="button"
            id="btn-area-professor"
            onClick={onOpenTeacher}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-amber-500/40 text-slate-300 hover:text-amber-300 text-xs font-medium transition-all shadow-sm group"
            title="Acesso exclusivo para o Professor Ederson"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-400 transition-colors" />
            <span className="tracking-wide">ÁREA DO PROFESSOR</span>
          </button>
        </div>
      </div>
    </header>
  );
};
