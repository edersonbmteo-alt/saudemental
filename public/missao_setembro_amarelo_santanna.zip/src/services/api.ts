import { SharedMessage, StudentDataRecord } from "../types";

export const api = {
  // Start or resume session
  async startSession(studentName: string, studentClass: string) {
    const res = await fetch("/api/session/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ studentName, studentClass }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: "Erro na conexão" }));
      throw new Error(err.error || "Não foi possível iniciar a sessão");
    }
    return res.json();
  },

  // Save student progress
  async saveProgress(data: Partial<StudentDataRecord> & { studentId: string }) {
    try {
      const res = await fetch("/api/progress/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      return await res.json();
    } catch (err) {
      console.warn("Could not save progress to server:", err);
      return { success: false };
    }
  },

  // Get shared wall messages
  async getMessages(): Promise<SharedMessage[]> {
    try {
      const res = await fetch("/api/messages");
      if (res.ok) {
        const data = await res.json();
        return data.messages || [];
      }
    } catch (err) {
      console.warn("Error fetching wall messages:", err);
    }
    return [];
  },

  // Post anonymous message to shared wall
  async postMessage(message: string): Promise<SharedMessage | null> {
    const res = await fetch("/api/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });
    if (res.ok) {
      const data = await res.json();
      return data.message;
    }
    return null;
  },

  // Like / Sunflower reaction
  async likeMessage(id: string): Promise<number | null> {
    try {
      const res = await fetch(`/api/messages/${id}/like`, { method: "POST" });
      if (res.ok) {
        const data = await res.json();
        return data.likes;
      }
    } catch (err) {
      console.warn("Error reacting to message:", err);
    }
    return null;
  },

  // Teacher login
  async teacherLogin(code: string, password: string) {
    const res = await fetch("/api/teacher/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, password }),
    });
    return res.json();
  },

  // Teacher get students
  async getTeacherStudents(token: string): Promise<StudentDataRecord[]> {
    const res = await fetch("/api/teacher/students", {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) throw new Error("Acesso negado");
    const data = await res.json();
    return data.students || [];
  },

  // Teacher clear data
  async clearTeacherData(token: string) {
    const res = await fetch("/api/teacher/clear", {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.json();
  },
};
