import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

const PORT = 3000;
const DATA_DIR = path.join(process.cwd(), "data");
const STUDENTS_FILE = path.join(DATA_DIR, "students.json");
const MESSAGES_FILE = path.join(DATA_DIR, "messages.json");

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initial starter messages for the shared sunflower wall
const INITIAL_MESSAGES = [
  {
    id: "msg-init-1",
    message: "Você não precisa carregar tudo sozinho. Sempre haverá alguém disposto a estender a mão e te ouvir.",
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    likes: 12
  },
  {
    id: "msg-init-2",
    message: "Assim como os girassóis buscam a luz mesmo nos dias nublados, mantenha a esperança no coração. Sua vida importa muito!",
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    likes: 18
  },
  {
    id: "msg-init-3",
    message: "Respire fundo, um passo de cada vez. Você é mais forte e especial do que imagina!",
    timestamp: new Date().toISOString(),
    likes: 9
  }
];

// Helper functions for reading and writing data safely
function readJsonFile<T>(filePath: string, defaultValue: T): T {
  try {
    if (fs.existsSync(filePath)) {
      const data = fs.readFileSync(filePath, "utf-8");
      return JSON.parse(data) as T;
    }
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err);
  }
  return defaultValue;
}

function writeJsonFile<T>(filePath: string, data: T): void {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error(`Error writing ${filePath}:`, err);
  }
}

// Seed initial messages if empty
if (!fs.existsSync(MESSAGES_FILE)) {
  writeJsonFile(MESSAGES_FILE, INITIAL_MESSAGES);
}

interface StudentRecord {
  id: string;
  studentName: string;
  studentClass: string;
  currentStep: number;
  quizScore: string;
  quizDetails: string;
  wordSearchFound: string[];
  sevenErrorsMarked: number;
  wordsGoodSelected: string[];
  wordsGoodReflection: string;
  crosswordResult: string;
  qualitiesSelected: string[];
  qualityRecognizedOwn: string;
  qualityToDevelop: string;
  finalMessage: string;
  completed: boolean;
  startedAt: string;
  updatedAt: string;
}

interface SharedMessage {
  id: string;
  message: string;
  timestamp: string;
  likes: number;
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // API Routes
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Start or resume session
  app.post("/api/session/start", (req, res) => {
    const { studentName, studentClass } = req.body;
    if (!studentName || !studentClass) {
      return res.status(400).json({ error: "Nome e Turma são obrigatórios" });
    }

    const students = readJsonFile<StudentRecord[]>(STUDENTS_FILE, []);
    const cleanName = String(studentName).trim();
    const cleanClass = String(studentClass).trim();

    // Check if student with exact name & class already started
    let student = students.find(
      (s) =>
        s.studentName.toLowerCase() === cleanName.toLowerCase() &&
        s.studentClass.toLowerCase() === cleanClass.toLowerCase()
    );

    if (!student) {
      student = {
        id: `std_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        studentName: cleanName,
        studentClass: cleanClass,
        currentStep: 1,
        quizScore: "Não realizado",
        quizDetails: "",
        wordSearchFound: [],
        sevenErrorsMarked: 0,
        wordsGoodSelected: [],
        wordsGoodReflection: "",
        crosswordResult: "Pendente",
        qualitiesSelected: [],
        qualityRecognizedOwn: "",
        qualityToDevelop: "",
        finalMessage: "",
        completed: false,
        startedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      students.push(student);
      writeJsonFile(STUDENTS_FILE, students);
    }

    res.json({ success: true, student });
  });

  // Save student progress
  app.post("/api/progress/save", (req, res) => {
    const {
      studentId,
      studentName,
      studentClass,
      currentStep,
      quizScore,
      quizDetails,
      wordSearchFound,
      sevenErrorsMarked,
      wordsGoodSelected,
      wordsGoodReflection,
      crosswordResult,
      qualitiesSelected,
      qualityRecognizedOwn,
      qualityToDevelop,
      finalMessage,
      completed,
    } = req.body;

    const students = readJsonFile<StudentRecord[]>(STUDENTS_FILE, []);
    let index = students.findIndex((s) => s.id === studentId);

    if (index === -1 && studentName && studentClass) {
      index = students.findIndex(
        (s) =>
          s.studentName.toLowerCase() === String(studentName).trim().toLowerCase() &&
          s.studentClass.toLowerCase() === String(studentClass).trim().toLowerCase()
      );
    }

    const now = new Date().toISOString();

    if (index !== -1) {
      const existing = students[index];
      students[index] = {
        ...existing,
        currentStep: currentStep !== undefined ? currentStep : existing.currentStep,
        quizScore: quizScore !== undefined ? quizScore : existing.quizScore,
        quizDetails: quizDetails !== undefined ? quizDetails : existing.quizDetails,
        wordSearchFound: wordSearchFound !== undefined ? wordSearchFound : existing.wordSearchFound,
        sevenErrorsMarked: sevenErrorsMarked !== undefined ? sevenErrorsMarked : existing.sevenErrorsMarked,
        wordsGoodSelected: wordsGoodSelected !== undefined ? wordsGoodSelected : existing.wordsGoodSelected,
        wordsGoodReflection: wordsGoodReflection !== undefined ? wordsGoodReflection : existing.wordsGoodReflection,
        crosswordResult: crosswordResult !== undefined ? crosswordResult : existing.crosswordResult,
        qualitiesSelected: qualitiesSelected !== undefined ? qualitiesSelected : existing.qualitiesSelected,
        qualityRecognizedOwn: qualityRecognizedOwn !== undefined ? qualityRecognizedOwn : existing.qualityRecognizedOwn,
        qualityToDevelop: qualityToDevelop !== undefined ? qualityToDevelop : existing.qualityToDevelop,
        finalMessage: finalMessage !== undefined ? finalMessage : existing.finalMessage,
        completed: completed !== undefined ? completed : existing.completed,
        updatedAt: now,
      };
    } else {
      const newRecord: StudentRecord = {
        id: studentId || `std_${Date.now()}`,
        studentName: studentName || "Anônimo",
        studentClass: studentClass || "Não informada",
        currentStep: currentStep || 1,
        quizScore: quizScore || "Pendente",
        quizDetails: quizDetails || "",
        wordSearchFound: wordSearchFound || [],
        sevenErrorsMarked: sevenErrorsMarked || 0,
        wordsGoodSelected: wordsGoodSelected || [],
        wordsGoodReflection: wordsGoodReflection || "",
        crosswordResult: crosswordResult || "Pendente",
        qualitiesSelected: qualitiesSelected || [],
        qualityRecognizedOwn: qualityRecognizedOwn || "",
        qualityToDevelop: qualityToDevelop || "",
        finalMessage: finalMessage || "",
        completed: completed || false,
        startedAt: now,
        updatedAt: now,
      };
      students.push(newRecord);
    }

    writeJsonFile(STUDENTS_FILE, students);
    res.json({ success: true, message: "Progresso salvo com sucesso" });
  });

  // Public Anonymous Wall Endpoints
  app.get("/api/messages", (_req, res) => {
    const messages = readJsonFile<SharedMessage[]>(MESSAGES_FILE, INITIAL_MESSAGES);
    // Sort newest first
    const sorted = [...messages].sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    res.json({ success: true, messages: sorted });
  });

  app.post("/api/messages", (req, res) => {
    const { message } = req.body;
    if (!message || String(message).trim().length < 3) {
      return res.status(400).json({ error: "Mensagem inválida" });
    }

    const messages = readJsonFile<SharedMessage[]>(MESSAGES_FILE, INITIAL_MESSAGES);
    const newMsg: SharedMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      message: String(message).trim(),
      timestamp: new Date().toISOString(),
      likes: 0,
    };

    messages.unshift(newMsg);
    writeJsonFile(MESSAGES_FILE, messages);

    res.json({ success: true, message: newMsg });
  });

  // Like / React with sunflower
  app.post("/api/messages/:id/like", (req, res) => {
    const { id } = req.params;
    const messages = readJsonFile<SharedMessage[]>(MESSAGES_FILE, INITIAL_MESSAGES);
    const msg = messages.find((m) => m.id === id);
    if (msg) {
      msg.likes = (msg.likes || 0) + 1;
      writeJsonFile(MESSAGES_FILE, messages);
      return res.json({ success: true, likes: msg.likes });
    }
    res.status(404).json({ error: "Mensagem não encontrada" });
  });

  // Teacher Area Endpoints
  app.post("/api/teacher/login", (req, res) => {
    const { code, password } = req.body;
    const cleanCode = String(code || "").trim().toUpperCase();
    const cleanPass = String(password || "").trim();

    if (cleanCode === "EDERSON" && cleanPass === "SANTANNA2026") {
      return res.json({
        success: true,
        token: "auth_prof_ederson_santanna_2026",
        teacherName: "Professor Ederson Braga Mello",
        institution: "Colégio Franciscano Sant’Anna",
      });
    }

    res.status(401).json({ success: false, error: "Código ou Senha incorretos." });
  });

  // Teacher get all students
  app.get("/api/teacher/students", (req, res) => {
    const auth = req.headers.authorization;
    if (auth !== "Bearer auth_prof_ederson_santanna_2026") {
      return res.status(401).json({ error: "Acesso não autorizado." });
    }

    const students = readJsonFile<StudentRecord[]>(STUDENTS_FILE, []);
    res.json({ success: true, students });
  });

  // Teacher export CSV
  app.get("/api/teacher/export-csv", (req, res) => {
    const auth = req.headers.authorization || (req.query.token as string);
    const valid =
      auth === "Bearer auth_prof_ederson_santanna_2026" ||
      auth === "auth_prof_ederson_santanna_2026";

    if (!valid) {
      return res.status(401).send("Não autorizado");
    }

    const students = readJsonFile<StudentRecord[]>(STUDENTS_FILE, []);

    // CSV Header matching prompt:
    // | Estudante | Turma | Quiz | Palavras | Cruzadinha | Qualidades | Reflexão | Mensagem | Conclusão |
    const headers = [
      "Estudante",
      "Turma",
      "Quiz",
      "Palavras",
      "Cruzadinha",
      "Qualidades",
      "Reflexão",
      "Mensagem",
      "Conclusão",
    ];

    const escapeCsv = (str: string) => {
      if (!str) return '""';
      const clean = String(str).replace(/"/g, '""').replace(/\r?\n/g, " ");
      return `"${clean}"`;
    };

    const rows = students.map((s) => [
      escapeCsv(s.studentName),
      escapeCsv(s.studentClass),
      escapeCsv(s.quizScore),
      escapeCsv(s.wordSearchFound?.join(", ") || "0 palavras"),
      escapeCsv(s.crosswordResult || "Pendente"),
      escapeCsv(
        [
          `Reconhecidas: ${s.qualitiesSelected?.join(", ") || "Nenhuma"}`,
          s.qualityRecognizedOwn ? `Própria: ${s.qualityRecognizedOwn}` : "",
          s.qualityToDevelop ? `A Desenvolver: ${s.qualityToDevelop}` : "",
        ]
          .filter(Boolean)
          .join(" | ")
      ),
      escapeCsv(s.wordsGoodReflection || "Não preenchido"),
      escapeCsv(s.finalMessage || "Não preenchido"),
      escapeCsv(s.completed ? `Concluído em ${new Date(s.updatedAt).toLocaleString("pt-BR")}` : `Em andamento (Desafio ${s.currentStep}/8)`),
    ]);

    // UTF-8 BOM (\uFEFF) for Excel compatibility with Portuguese accents
    const csvContent = "\uFEFF" + [headers.join(";"), ...rows.map((r) => r.join(";"))].join("\r\n");

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="Missao_Setembro_Amarelo_SantAnna_${new Date().toISOString().slice(0, 10)}.csv"`
    );
    res.send(csvContent);
  });

  // Teacher reset data (optional for teacher management)
  app.post("/api/teacher/clear", (req, res) => {
    const auth = req.headers.authorization;
    if (auth !== "Bearer auth_prof_ederson_santanna_2026") {
      return res.status(401).json({ error: "Não autorizado." });
    }
    writeJsonFile(STUDENTS_FILE, []);
    res.json({ success: true, message: "Dados dos estudantes reiniciados com sucesso." });
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
